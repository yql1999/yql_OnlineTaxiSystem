package cn.edu.zjut.service;

import cn.edu.zjut.po.Order;

public interface IOrderService {
	public void save(Order transientInstance);
	
}
