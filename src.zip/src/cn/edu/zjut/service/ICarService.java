package cn.edu.zjut.service;

import cn.edu.zjut.po.Car;

public interface ICarService {
	public void save(Car transientInstance);
	
}
