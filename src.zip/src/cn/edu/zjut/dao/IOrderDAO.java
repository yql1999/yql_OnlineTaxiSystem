package cn.edu.zjut.dao;

import cn.edu.zjut.po.Order;

public interface IOrderDAO {
	public void save(Order transientInstance);
	public Order findbyId(Order transientInstance);
}
