package cn.edu.zjut.action;

import cn.edu.zjut.po.Order;
import cn.edu.zjut.service.IOrderService;

public class OrderAction {
	private Order order;
	private IOrderService orderService;
	
	public String save() {
		orderService.save(order);
		return "success";
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public IOrderService getOrderService() {
		return orderService;
	}

	public void setOrderService(IOrderService orderService) {
		this.orderService = orderService;
	}
	
}
